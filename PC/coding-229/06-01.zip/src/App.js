import React, { Component } from 'react';

class App extends Component {
  render() {
    return (
      <div className='dell'>
        hello world
      </div>
    );
  }
}

export default App;
