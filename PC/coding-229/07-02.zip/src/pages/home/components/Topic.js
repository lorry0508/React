import React, { Component } from 'react';

class Topic extends Component {
	render() {
		return (
			<div>Topic~</div>
		)
	}
}

export default Topic;