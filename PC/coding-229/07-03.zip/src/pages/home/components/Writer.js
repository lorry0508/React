import React, { Component } from 'react';

class Writer extends Component {
	render() {
		return (
			<div>Writer~</div>
		)
	}
}

export default Writer;