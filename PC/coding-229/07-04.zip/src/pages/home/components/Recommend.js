import React, { Component } from 'react';

class Recommend extends Component {
	render() {
		return (
			<div>Recommend~</div>
		)
	}
}

export default Recommend;