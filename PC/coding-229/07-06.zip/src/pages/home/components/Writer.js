import React, { Component } from 'react';
import { WriterWrapper } from '../style';

class Writer extends Component {
	render() {
		return (
			<WriterWrapper>HomeWork</WriterWrapper>
		)
	}
}

export default Writer;